# jamai-core 🎸

JamAI's composition workshop: tools that **listen** to what was played, **render** it so it can
be heard and read, **publish** it on a page of your own, and **tell the people who subscribed**.

Everything here was written during real composition sessions, each tool at the moment something
was missing. Version 0.2.0 makes the set installable by someone who is not in the house where it
was born: one command, and it asks for every setting it needs.

## Install

**With apt** (Debian, Ubuntu): it brings the system programs too, and `sudo apt upgrade` brings
each new version.

```bash
curl -fsSL https://apt.gmusicassembly.com/setup.sh | sudo bash
sudo apt install jamai
jamai setup
```

The first line runs once. It adds the JamAI repository and its signing key, after checking the key
is the right one: `53A00775B61CAA93A047C92C1BA4BD935B04BE3C`. The steps by hand, and every version
published: [apt.gmusicassembly.com](https://apt.gmusicassembly.com). Until 0.4.1 the package was
called `jamai-core`; `jamai` replaces it.

**One line, no root needed** (Linux or macOS with bash and git):

```bash
curl -fsSL https://raw.githubusercontent.com/gmusic1007/jamai-core/main/install.sh | bash
```

It clones the repository into `~/.local/share/jamai-core`, asks its questions on your terminal, and
links the commands into `~/.local/bin`. Then `jamai doctor` names any system program still missing.

**From a clone**, to change the code:

```bash
git clone https://github.com/gmusic1007/jamai-core.git
./jamai-core/install.sh
```

The installer does four things, in this order:

1. **Asks the settings** declared in [`settings`](settings): where the commands go, which
   soundfont, where older ABC sessions live, where melodies are published and under which
   public address, the hub's port, the screen and speaker names. Enter keeps the value shown in brackets.
2. **Writes them** to `~/.config/jamai/jamai.env` (plain `KEY=VALUE`). The one secret, the hub's
   admin token, is generated and kept apart in `secrets.env`, mode 600.
3. **Links the 19 commands** into the folder you chose (default `~/.local/bin`). A file already
   there is renamed `name.bak-<stamp>`, never deleted.
4. **Runs `jamai doctor`**, which names each missing program, the package that brings it, and
   what stops working without it.

| | |
|---|---|
| `./install.sh --yes` | no questions: defaults, or values already in the environment |
| `./install.sh --check` | changes nothing, exits 1 if a command is not linked to this checkout |
| `./install.sh --dry-run` | says what an install would do |
| `./install.sh --uninstall` | removes the links, keeps your config |

**System programs**, if you did not install with apt (Debian and Ubuntu names): `abcmidi abcm2ps fluidsynth fluid-soundfont-gm
lame ffmpeg jq librsvg2-bin imagemagick python3-numpy python3-scipy python3-pil`. Optional, for
a screen and a speaker: `pipx install catt edge-tts`. Tested on Ubuntu. Other systems are untested.

MuseScore is not needed for the commands above. To add it, and to let an agent change the score open
on your screen: [MuseScore: activate it, step by step](#musescore-activate-it-step-by-step).

## A first melody

```bash
jamai-render examples/first-light.abc            # hear it and read it; nothing is published
jamai-publish-melody examples/first-light.abc    # add it to your melody page
```

`jamai-publish-melody` renders ABC to MIDI, WAV and MP3, engraves the score, updates
`melodies.json` and the index page in `JAMAI_MELODY_DIR`, and prints the listen address. With
`JAMAI_PUBLIC_BASE` empty, that address is a file on your machine: no web host is needed to start.

A soft arrangement renders quiet. `--gain-db 10` (or `JAMAI_GAIN_DB`) lifts both the WAV and the MP3.
The gain is linear with no limiter, so measure the peak before going far: a loud piece can clip.

## Settings

Three sources, first match wins: the environment, then `~/.config/jamai/jamai.env`, then the
default in `settings`.

```bash
jamai config show                 # every setting, its value, and where the value comes from
jamai config set JAMAI_PUBLIC_BASE https://example.org/melody
jamai setup                       # ask them all again
```

Nothing about where you publish is built into a tool. The self-test fails if a house address
appears in the packaged code.

## MuseScore: activate it, step by step

jamai-core works with MuseScore Studio 4 in two ways:

- **With no window**: export, video and metadata, through MuseScore's own converter. Needs step 1 only.
- **Live**: an agent changes the score open on your screen while you watch. Needs steps 1 to 4.

### 1. Install or update MuseScore

```bash
jamai-musescore --install-musescore                  # the latest MuseScore Studio
jamai-musescore --install-musescore --version 4.7.7  # a given version
jamai-musescore --install-musescore --dry-run        # say what it would do, download nothing
```

On Linux (x86_64 or aarch64), it takes the AppImage from MuseScore's GitHub releases and checks it
against the sha256 GitHub publishes for that file: a file that does not match is refused. It installs
for you only, with no sudo, in `~/.local/share/jamai/musescore`, keeps older versions beside it,
sets `JAMAI_MUSESCORE_BIN`, adds a `musescore4` command unless you already have one, and does step 2.
Run it again to update. AppImages need libfuse2: `sudo apt install libfuse2t64` on Ubuntu 24.04,
`libfuse2` on older ones.

On macOS or Windows, install MuseScore Studio from [musescore.org](https://musescore.org/download),
then point jamai-core at it: `jamai config set JAMAI_MUSESCORE_BIN "<path to MuseScore>"`. Untested there.

Check: `jamai doctor` shows `ok  score  musescore`.

### 2. Put the plugin in place

```bash
jamai-musescore --install-plugin
```

`install.sh` and `--install-musescore` already do it. The plugin goes in the folder MuseScore reads
plugins from (the one in MuseScore's settings, else `~/Documents/MuseScore4/Plugins`).
Check: `jamai doctor` shows `ok  live  plugin`.

### 3. Enable it in MuseScore, once

Open MuseScore, then **Home → Plugins**, click **musescore-mcp-websocket**, then **Enable**.

### 4. Start it, each session

Open the score you want to work on, then **Plugins → musescore-mcp-websocket**.

- MuseScore 4 gives each score its own window. The plugin changes the score of the window where you
  started it, and only that one.
- Only one window can run it at a time. To work on another score, close the window where it runs,
  then start it in the other one.

### 5. Check that it answers

```bash
jamai-musescore --live version     # "variant": "jamai-core", "version": "0.4.4"
jamai-musescore --live getScore    # what the open score holds
```

### 6. Ask for changes

From an agent with `jamai-mcp` (see [For an agent](#for-an-agent-mcp-server-and-claude-plugin)), in words:
"add a flute part", "a forte on the third note", "a trill on the first note of measure 2",
"tempo 72 here", "export a PDF and an MP3". From a terminal:

```bash
jamai-musescore --live addNote '{"pitch": 60, "duration": {"numerator": 1, "denominator": 4}, "advanceCursorAfterAction": true}'
jamai-musescore --live addElement '{"kind": "articulation", "name": "staccato"}'
```

MuseScore's undo (Ctrl+Z) reverses each change.

### After updating jamai-core

Run `jamai-musescore --install-plugin`, then **quit MuseScore completely and reopen it**. A running
MuseScore keeps answering with the plugin copy it started first. If the plugin is listed under
Disabled in Home → Plugins after the update, enable it again.

### When it does not answer

| you see | why | do |
|---|---|---|
| `MuseScore is not listening on port 8765` | the plugin is not started | step 4 |
| `Unknown command: version` | an older copy of the plugin is running | quit and reopen MuseScore |
| `QTcpServer::listen() called when already listening` in MuseScore's log | the plugin was started twice; the first copy keeps the port | quit and reopen MuseScore |
| the plugin is not in the Plugins menu | not enabled, or not in the plugins folder | step 3, or `jamai-musescore --install-plugin`, then restart MuseScore |
| `MuseScore is not installed` | no MuseScore found | step 1 |

### What it reaches, and what comes next

- Every live action and its parameters, and what was tried in MuseScore 4.7.7: [musescore/README.md](musescore/README.md).
- Every page of the MuseScore handbook, and how jamai-core reaches it: [musescore/CAPABILITIES.md](musescore/CAPABILITIES.md).
- What still stays by hand, and the routes to reach it by asking: [musescore/VISION.md](musescore/VISION.md), tracked in gmusic1007/jamai-core#7.

The plugin comes from [mcp-musescore-gmusic](https://github.com/Gerico1007/mcp-musescore-gmusic), MIT.

### With no window: export, video, metadata

```bash
jamai-musescore --export pdf,mp3,musicxml song.mscz    # mscz mscx pdf png svg mid musicxml mxl mei mp3 flac ogg wav aac
jamai-musescore --export pdf --parts song.mscz         # every part after the full score
jamai-musescore --export musicxml --transpose-semitones 2 song.mscz
jamai-musescore --video song.mscz                      # MP4 of the score scrolling, with its audio
jamai-musescore --meta song.mscz                       # title, key, measures, parts… as JSON
```

### Older sessions

```bash
jamai-legacy list ~/old-sessions            # every ABC session under a folder: date, key, meter, tempo, title
jamai-musescore ~/old-sessions/theme.abc    # open one in MuseScore as a score you can edit
jamai-publish-melody ~/old-sessions/theme.abc
```

A legacy session is plain ABC, so every command takes it as it is. `jamai-musescore` goes through
MIDI: `abc2midi` writes the MIDI file and MuseScore's own converter turns it into MusicXML. Notes,
rhythm, tempo, key and instruments come through. Chord symbols, lyrics and voice names do not.
`--no-open` converts without opening a window. Set `JAMAI_LEGACY_DIRS` to list without naming a
folder each time.

## People who want your music: the hub

After each publication, `jamai-publish-melody` appends one fact to a ledger and delivers nothing
itself:

| fact | when |
|---|---|
| `melody.published` | the slug is new |
| `melody.revised` | the slug existed and the music changed (the MIDI differs) |
| none | the MIDI is byte-identical, so an engraving fix notifies nobody twice |

A fact carries the title, the links to the MP3, MIDI and score, key, meter, tempo, duration and
a digest of the MIDI. It never carries the ABC source. The session note stays on the page unless
you set `JAMAI_PUBLISH_NOTE_PUBLIC=1`.

`jamai-hub serve` runs the service: your melody page, a subscribe page, and a worker that POSTs
each fact once to every subscriber.

```bash
jamai-hub serve                           # http://127.0.0.1:8642/
jamai-hub invite "a friend's studio"      # a one-use code to hand to that person
jamai-hub subscriptions                   # who is subscribed (never the secrets)
jamai-hub unit > ~/.config/systemd/user/jamai-hub.service   # keep it running
```

A subscriber gives a webhook address and receives an id and a secret, shown once. Every delivery
is signed with that secret. On the receiving side:

```python
import hashlib, hmac
expected = "sha256=" + hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
trusted = hmac.compare_digest(expected, request.headers["X-JamAI-Signature"])
```

What the hub refuses by default: a subscription without an invite code, a webhook that is not
https, a webhook that resolves to a private or local address (checked again at each delivery),
and redirects. A subscription receives what is announced after it, counted by position in the
ledger. A failed delivery is tried again five times over about nine hours.

The hub has no accounts and no sign-in. A person manages a subscription with its id and secret.

## For an agent: MCP server and Claude plugin

```bash
claude mcp add jamai -- jamai-mcp                         # the tools, in Claude Code
claude plugin marketplace add gmusic1007/jamai-core       # or the plugin: tools plus a skill
claude plugin install jamai@jamai-core
```

`jamai-mcp` offers sixteen tools over stdio: `jamai_doctor`, `jamai_config`, `jamai_render`,
`jamai_midi_notes`, `jamai_chords`, `jamai_tab`, `jamai_legacy_list`, `jamai_musescore`,
`jamai_publish_melody`, `jamai_list_melodies`, `jamai_events`, and for the score open in MuseScore,
`musescore_live_status`, `musescore_get_score`, `musescore_live`, `musescore_export` and
`musescore_video`. Only `jamai_publish_melody`
changes a published page, only `jamai_musescore` with `open: true` opens a window, and only
`musescore_live` changes the open score. The plugin adds the
[`jamai` skill](claude/jamai/skills/jamai/SKILL.md): the order of work, and the traps that each
cost a session to find. The plugin needs jamai-core installed first, since it calls `jamai-mcp`
by name.

## The commands

`jamai tools` prints this list.

| folder | command | what it does |
|---|---|---|
| `listen/` | `jamai-midi.py` | MIDI to a note-by-note listing and ABC |
| | `jamai-chords.py` | the chord sounding on each beat of a MIDI file |
| | `jamai-chords-audio.py` | chords and key from a recording |
| | `jamai-measure.py` | tempo, structure, pitch and timbre of a recording |
| | `jamai-grille.py` | measure the bar grid before writing the score |
| `render/` | `jamai-render` | ABC to MIDI, WAV, MP3 and an engraved score |
| | `jamai-musescore` | install or update MuseScore; open a melody in it; export, video and metadata with no window; live control (`--live`) |
| | `jamai-tab.py` | six-line guitar tablature from ABC |
| | `jamai-score-video.py` | score video, one system at a time |
| | `jamai-scroll.py` | score video scrolling left to right under a red playhead |
| `publish/` | `jamai-publish-melody` | render a melody and add it to the melody page |
| | `jamai-hub` | the melody page, subscriptions and webhook delivery |
| `workshop/` | `jamai-legacy` | ABC sessions written before the package, ready to open or publish |
| `broadcast/` | `jamai-cast` | an HTML page on a Chromecast screen |
| | `jamai-say` | a spoken sentence on a Chromecast speaker |
| `moments/` | `routine` | a named moment of a house: its screen, speaker and posture |
| `mcp/` | `jamai-mcp` | the tools as an MCP server |
| `suno/` | `jamai-suno` | a composition to a Suno song, through your own Suno account: `prepare`, `generate`, `tools`, `login`, `status` ([suno/README.md](suno/README.md)) |
| `bin/` | `jamai` | setup, config, doctor |

## Proof

```bash
tests/selftest.sh
```

It installs into a throwaway folder and checks 103 things: the settings and the links, a render,
the three publication cases, the hub's invite, signature, single delivery and refusals, byte
ranges, a legacy session listed, converted for MuseScore and published, the defects fixed under
gmusic1007/jamai-core#4, live control against a stand-in MuseScore, the MCP server, and that no house address is in the packaged code. Where MuseScore is absent, its three checks are
skipped and one other check confirms the command says so. It touches none of
your files and reaches no outside address.

## Where this comes from

The first nine tools were written between 3 and 14 August 2026, during composition sessions with
Jerry ⚡ of the G.Music Assembly, and gathered here from the places they had grown. An earlier
`Gerico1007/Jamai-core` (May 2025) held nine empty module folders: an architecture drawn before a
note was played. This repository took the name and left the plan. It packages only what runs.

Not in the package yet: the drop watcher and transcription (`jamai-on-drop`, `jamai-watch`), the
footage clip tools and the speaker bridge.

*♠️🌿🎸🧵 G.Music Assembly*
